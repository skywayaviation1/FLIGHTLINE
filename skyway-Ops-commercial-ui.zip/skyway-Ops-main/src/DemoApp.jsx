import React, { useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, Bell, CalendarDays,
  Check, ChevronDown, Clock3, CloudSun, FileText, Fuel, Gauge,
  LayoutDashboard, MapPin, Menu, MessageSquare, Plane, Plus, Receipt,
  Search, Settings, ShieldCheck, UserRound, Users, Wifi, Wrench, X,
} from 'lucide-react';
import './demo-app.css';

const flights = [
  { id: '4821', time: '08:30', tail: 'N525CR', type: 'CJ3+', from: 'KTPA', to: 'KTEB', crew: 'Cambria / Smith', pax: 6, status: 'En route', tone: 'blue', eta: '11:04' },
  { id: '4824', time: '11:15', tail: 'N444AM', type: 'King Air 350', from: 'KPBI', to: 'KLAS', crew: 'Jones / Lee', pax: 4, status: 'Delayed', tone: 'amber', eta: '15:02' },
  { id: '4828', time: '14:40', tail: 'N286N', type: 'Citation Excel', from: 'KLAS', to: 'KVNY', crew: 'Davis / Young', pax: 3, status: 'Scheduled', tone: 'gray', eta: '15:38' },
  { id: '4830', time: '17:10', tail: 'N168ZZ', type: 'Learjet 60', from: 'KTEB', to: 'KPBI', crew: 'Miller / Hall', pax: 7, status: 'Preflight', tone: 'green', eta: '20:06' },
];

const nav = [
  ['overview', 'Overview', LayoutDashboard], ['operations', 'Operations', Activity],
  ['trips', 'Trips', CalendarDays], ['fleet', 'Fleet', Plane], ['crew', 'Crew', Users],
  ['maintenance', 'Maintenance', Wrench], ['messages', 'Messages', MessageSquare],
  ['expenses', 'Expenses', Receipt], ['settings', 'Settings', Settings],
];

function Badge({ children, tone = 'gray' }) { return <span className={`demo-badge ${tone}`}>{children}</span>; }
function IconButton({ children, label, onClick }) { return <button className="demo-icon-btn" aria-label={label} onClick={onClick}>{children}</button>; }
function Metric({ label, value, detail, tone = 'blue' }) {
  return <article className="demo-metric"><div className={`demo-metric-icon ${tone}`}><Activity size={18}/></div><div><p>{label}</p><strong>{value}</strong><span>{detail}</span></div></article>;
}

function OpsOverview({ openTrip }) {
  return <div className="demo-page">
    <div className="demo-page-title"><div><span className="demo-eyebrow">Sunday, July 19</span><h1>Operations overview</h1><p>Good afternoon, Jake. Here’s what needs attention across the operation.</p></div><button className="demo-primary"><Plus size={17}/> New trip</button></div>
    <section className="demo-metrics">
      <Metric label="Flights today" value="12" detail="8 completed · 4 active" />
      <Metric label="Fleet available" value="7 / 8" detail="1 aircraft in maintenance" tone="green" />
      <Metric label="Crew on duty" value="9" detail="2 approaching limits" tone="amber" />
      <Metric label="Open alerts" value="4" detail="1 requires immediate action" tone="red" />
    </section>
    <div className="demo-grid-main">
      <section className="demo-panel demo-flight-panel">
        <div className="demo-panel-head"><div><h2>Live flight board</h2><p>Current and upcoming operations</p></div><div className="demo-segment"><button className="active">Table</button><button>Timeline</button><button>Map</button></div></div>
        <div className="demo-table-wrap"><table><thead><tr><th>Departure</th><th>Aircraft</th><th>Route</th><th>Crew</th><th>Pax</th><th>Status</th><th></th></tr></thead><tbody>{flights.map(f => <tr key={f.id} onClick={() => openTrip(f)}><td className="mono">{f.time}</td><td><b className="mono">{f.tail}</b><small>{f.type}</small></td><td><b className="mono">{f.from} <ArrowRight size={13}/> {f.to}</b><small>ETA {f.eta}</small></td><td>{f.crew}</td><td>{f.pax}</td><td><Badge tone={f.tone}>{f.status}</Badge></td><td><ArrowRight size={16}/></td></tr>)}</tbody></table></div>
      </section>
      <aside className="demo-panel demo-alerts"><div className="demo-panel-head"><div><h2>Attention queue</h2><p>Prioritized by operational impact</p></div><Badge tone="red">4 open</Badge></div>
        <Alert tone="red" tag="Critical" title="Brake discrepancy" text="N444AM · departure in 2h 14m" action="Open case" />
        <Alert tone="amber" tag="Crew duty" title="Jones · 56 min remaining" text="Projected overage on Trip 4824" action="Review crew" />
        <Alert tone="blue" tag="Action required" title="Manifest incomplete" text="Trip 4828 · 1 passenger missing" action="Review trip" />
        <Alert tone="gray" tag="Information" title="Catering change received" text="Trip 4830 · KTEB departure" />
      </aside>
    </div>
    <section className="demo-panel"><div className="demo-panel-head"><div><h2>Fleet readiness</h2><p>Dispatch status across 8 aircraft</p></div><button className="demo-link">View fleet <ArrowRight size={14}/></button></div><div className="demo-fleet-strip">{['N20UF','N168ZZ','N286N','N444AM','N651TW','N551FP','N85AH','N525CR'].map((t,i)=><div key={t}><span className={`status-dot ${i===3?'red':i===6?'amber':'green'}`}/><b className="mono">{t}</b><small>{i===3?'Maintenance':i===6?'Restricted':'Ready'}</small></div>)}</div></section>
  </div>;
}

function Alert({ tone, tag, title, text, action }) { return <div className={`demo-alert ${tone}`}><span className="demo-alert-line"/><div><Badge tone={tone}>{tag}</Badge><h3>{title}</h3><p>{text}</p>{action && <button>{action} <ArrowRight size={13}/></button>}</div></div>; }

function PilotHome({ openTrip, setPage }) {
  const trip = flights[0];
  return <div className="pilot-page">
    <header className="pilot-hello"><div><span>Sunday, July 19</span><h1>Good afternoon, Jake</h1></div><div className="pilot-avatar">JC</div></header>
    <div className="sync-pill"><Wifi size={14}/><span>Synced just now</span><i/>Online</div>
    <section className="duty-card"><div className="duty-head"><div><span className="status-dot green"/>On duty</div><Badge tone="green">Legal</Badge></div><div className="duty-time"><div><span>Duty started</span><strong>09:15</strong></div><div><span>Time remaining</span><strong>7h 42m</strong></div></div><div className="duty-bar"><i/></div><p>Maximum duty ends at 18:57 EDT</p><button>View duty details</button></section>
    <section className="next-trip"><div className="next-label"><span>Next trip</span><Badge tone="blue">Boarding in 1h 18m</Badge></div><div className="tail-row"><div><strong className="mono">{trip.tail}</strong><span>{trip.type}</span></div><Plane size={24}/></div><div className="route"><div><strong>{trip.from.slice(1)}</strong><span>Tampa</span><b>14:30 EDT</b></div><div className="route-line"><Plane size={17}/><i/></div><div><strong>{trip.to.slice(1)}</strong><span>Teterboro</span><b>17:04 EDT</b></div></div><div className="trip-facts"><div><Users size={16}/><span>6 passengers</span></div><div><CloudSun size={16}/><span>VFR · 82°F</span></div><div><ShieldCheck size={16}/><span>Aircraft ready</span></div></div><button className="demo-primary full" onClick={()=>openTrip(trip)}>Open trip <ArrowRight size={17}/></button></section>
    <section><div className="mobile-section-head"><h2>Quick actions</h2></div><div className="quick-grid"><Quick icon={Check} label="Checklist"/><Quick icon={FileText} label="Manifest"/><Quick icon={Wrench} label="Report MX" onClick={()=>setPage('maintenance')}/><Quick icon={Receipt} label="Receipt" onClick={()=>setPage('expenses')}/></div></section>
    <section className="pilot-notices"><div className="mobile-section-head"><h2>Before departure</h2><Badge>3 items</Badge></div><div><Check size={17}/><span><b>Hotel confirmed</b><small>Westin Jersey City · Conf. 845921</small></span></div><div><Check size={17}/><span><b>Rental car confirmed</b><small>National · Executive aisle</small></span></div><div className="notice-warn"><AlertTriangle size={17}/><span><b>Catering updated</b><small>New delivery time · 13:45 EDT</small></span><ArrowRight size={16}/></div></section>
  </div>;
}
function Quick({icon:Icon,label,onClick}) { return <button onClick={onClick}><span><Icon size={21}/></span>{label}</button>; }

function TripDetail({ trip, close }) {
  return <div className="demo-page trip-detail"><button className="back-btn" onClick={close}><ArrowLeft size={17}/> Back to trips</button><div className="trip-hero"><div><div className="trip-title-line"><Badge tone="blue">En route</Badge><span>Trip {trip.id}</span></div><h1><span className="mono">{trip.from}</span><ArrowRight/><span className="mono">{trip.to}</span></h1><p>{trip.tail} · {trip.type} · Sunday, July 19</p></div><button className="demo-secondary">Trip actions <ChevronDown size={15}/></button></div><div className="trip-warning"><AlertTriangle size={18}/><div><b>Catering delivery time changed</b><span>Updated to 13:45 EDT. Crew acknowledgement required.</span></div><button>Acknowledge</button></div><div className="trip-columns"><main>
    <TripSection title="Flight schedule" icon={Plane}><div className="leg-row"><div><b className="mono">14:30</b><span>EDT</span></div><i/><div><strong className="mono">{trip.from}</strong><span>Signature Flight Support</span></div><ArrowRight/><div><strong className="mono">{trip.to}</strong><span>Atlantic Aviation</span></div><div><b className="mono">17:04</b><span>EDT</span></div></div></TripSection>
    <TripSection title="Passengers" icon={Users} action="View manifest"><div className="detail-summary"><div><strong>6</strong><span>Confirmed</span></div><div><strong>6</strong><span>IDs verified</span></div><div><strong>0</strong><span>Special requests</span></div></div></TripSection>
    <TripSection title="Logistics" icon={MapPin}><div className="logistics"><div><Check/><span><b>Catering</b><small>Air Culinaire · delivery 13:45</small></span></div><div><Check/><span><b>Hotel</b><small>Westin Jersey City · 2 rooms</small></span></div><div><Check/><span><b>Ground transportation</b><small>National · Executive aisle</small></span></div></div></TripSection>
  </main><aside><TripSection title="Aircraft" icon={Gauge}><Info label="Tail" value={trip.tail}/><Info label="Status" value="Ready" green/><Info label="Fuel" value="6,100 lb"/><Info label="Open MEL" value="None" green/></TripSection><TripSection title="Crew" icon={Users}><Info label="PIC" value="Jake Cambria"/><Info label="SIC" value="John Smith"/><Info label="Duty remaining" value="7h 42m" green/></TripSection><TripSection title="Weather" icon={CloudSun}><div className="weather"><strong>VFR</strong><span>220° at 8 kt · 10 SM</span><small>Few clouds at 4,500 ft</small></div></TripSection></aside></div></div>;
}
function TripSection({title,icon:Icon,action,children}) { return <section className="demo-panel trip-section"><div className="demo-panel-head"><div className="section-title"><Icon size={18}/><h2>{title}</h2></div>{action&&<button className="demo-link">{action} <ArrowRight size={14}/></button>}</div>{children}</section>; }
function Info({label,value,green}) { return <div className="info-row"><span>{label}</span><b className={green?'good':''}>{value}</b></div>; }

function GenericPage({ page }) {
  const labels={trips:'Trips',fleet:'Fleet',crew:'Crew',maintenance:'Maintenance',messages:'Messages',expenses:'Expenses',settings:'Organization settings',operations:'Live operations'};
  return <div className="demo-page"><div className="demo-page-title"><div><span className="demo-eyebrow">Skyway Aviation</span><h1>{labels[page]||'Workspace'}</h1><p>Professional, tenant-aware workspace using the shared application system.</p></div><button className="demo-primary"><Plus size={17}/> New record</button></div><section className="demo-panel generic-panel"><div className="demo-panel-head"><div><h2>{labels[page]} workspace</h2><p>Search, filter, save views, and manage records.</p></div><div className="demo-search"><Search size={16}/><span>Search records…</span></div></div><div className="generic-list">{flights.map((f,i)=><div key={f.id}><span className={`status-dot ${i===1?'amber':'green'}`}/><div><b className="mono">{page==='fleet'?f.tail:`${labels[page]} record ${i+1}`}</b><small>{f.from} → {f.to} · Updated {i+2} min ago</small></div><Badge tone={i===1?'amber':'green'}>{i===1?'Needs attention':'Active'}</Badge><ArrowRight size={16}/></div>)}</div></section></div>;
}

export default function DemoApp() {
  const mobile = typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches;
  const [role,setRole]=useState(mobile?'pilot':'ops'); const [page,setPage]=useState('overview'); const [trip,setTrip]=useState(null); const [menu,setMenu]=useState(false);
  const allowed=useMemo(()=>role==='pilot'?nav.filter(n=>['overview','trips','messages','expenses','maintenance'].includes(n[0])):nav,[role]);
  const select=(id)=>{setPage(id);setTrip(null);setMenu(false)};
  const content=trip?<TripDetail trip={trip} close={()=>setTrip(null)}/>:role==='pilot'&&page==='overview'?<PilotHome openTrip={setTrip} setPage={select}/>:page==='overview'?<OpsOverview openTrip={setTrip}/>:<GenericPage page={page}/>;
  return <div className={`demo-app ${role}`}>
    <aside className={`demo-sidebar ${menu?'open':''}`}><div className="org-switch"><img src="/icon-192.png"/><div><small>Organization</small><b>Skyway Aviation</b></div><ChevronDown size={15}/></div><nav>{allowed.map(([id,label,Icon])=><button key={id} className={page===id&&!trip?'active':''} onClick={()=>select(id)}><Icon size={18}/><span>{label}</span>{id==='messages'&&<em>3</em>}</button>)}</nav><div className="sidebar-foot"><div className="avatar">JC</div><div><b>Jake Cambria</b><small>{role==='pilot'?'Pilot':'Administrator'}</small></div></div></aside>
    {menu&&<button className="menu-scrim" onClick={()=>setMenu(false)} aria-label="Close menu"/>}
    <div className="demo-shell"><header className="demo-topbar"><div className="top-left"><IconButton label="Menu" onClick={()=>setMenu(true)}><Menu/></IconButton><div className="mobile-brand"><img src="/skyway-logo-nav.png"/></div><div className="global-search"><Search size={17}/><span>Search trips, tails, crew, airports…</span><kbd>⌘K</kbd></div></div><div className="top-actions"><div className="online"><i/> Live</div><IconButton label="Notifications"><Bell/></IconButton><button className="role-switch" onClick={()=>{setRole(role==='pilot'?'ops':'pilot');setPage('overview');setTrip(null)}}><UserRound size={16}/><span>{role==='pilot'?'Pilot view':'Ops view'}</span><ChevronDown size={14}/></button></div></header><main className="demo-content">{content}</main></div>
    <nav className="demo-bottom-nav">{allowed.slice(0,5).map(([id,label,Icon])=><button key={id} className={page===id&&!trip?'active':''} onClick={()=>select(id)}><Icon/><span>{label}</span></button>)}</nav>
  </div>;
}
